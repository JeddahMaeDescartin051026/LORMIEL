SCENTE PERFUME WEBSITE

Files:
- index.html
- style.css
- script.js

INSTALL:
1. Upload all three files to the same folder on your hosting, normally HTDOCS.
2. Make sure index.html is in the website's public/root folder.
3. Open your domain.

FUNCTIONS INCLUDED:
- Responsive desktop/mobile design
- Mobile navigation
- Product catalog
- Product filtering
- Product details modal
- Add to cart
- Quantity controls
- Remove from cart
- Cart saved in browser localStorage
- Search
- Checkout form
- Account demo
- Perfume bar inquiry form
- Contact form
- Instagram section
- Smooth scrolling

IMPORTANT:
This is a fully functional FRONT-END storefront. The checkout, account, and contact forms are demo/client-side functions. They do not actually charge cards, create server accounts, send email, or save orders to a database.

For LIVE ORDERS, connect the checkout to a real payment/order backend such as your preferred payment provider and a database/order system. Do not collect or store card numbers in this HTML/JavaScript.
